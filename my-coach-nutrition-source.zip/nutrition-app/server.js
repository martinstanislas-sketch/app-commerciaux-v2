// server.js
// My Coach Nutrition - serveur Express.
// Sert le front statique + une petite API de generation de plans.
// Sans ANTHROPIC_API_KEY -> mode DEMO (recettes locales). Avec cle -> Claude.

// Charge .env si dotenv est installe (optionnel).
try {
  require('dotenv').config();
} catch (_) {
  /* dotenv non installe : on lit process.env directement */
}

const path = require('path');
const express = require('express');

const { calculerBesoins } = require('./lib/nutrition');
const {
  genererPlanDemo,
  regenererRepas,
  recettesCompatibles,
  familiesFromUserAllergies,
} = require('./lib/planGenerator');
const { genererPlanIA, regenererRepasIA, iaDisponible } = require('./lib/aiGenerator');

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

// Petite graine pseudo-aleatoire basee sur l'heure, transmise au generateur
// pour que chaque clic "Nouveau plan" varie sans casser le determinisme interne.
function seedFromRequest(body) {
  if (body && Number.isFinite(Number(body.seed))) return Number(body.seed);
  return Math.floor(Date.now() % 2147483646) + 1;
}

// CEINTURE + BRETELLES : retire toute recette qui contiendrait malgre tout un
// allergene/aliment interdit (utile surtout pour les sorties IA).
function filtreSecuriteFinal(plan, prefs) {
  const compatiblesIds = new Set(recettesCompatibles(require('./lib/recipes').RECIPES, prefs).map((r) => r.id));
  const familles = familiesFromUserAllergies(prefs.allergies);
  let retirees = 0;
  for (const jour of plan.jours || []) {
    for (const repas of jour.repas || []) {
      const r = repas.recette;
      if (!r) continue;
      // Si la recette vient du catalogue local et n'est pas compatible -> on coupe.
      if (r.id && compatiblesIds.size && !compatiblesIds.has(r.id) && !String(r.id).startsWith('ia-')) {
        repas.recette = null;
        retirees++;
      }
    }
  }
  if (retirees) plan.avertissementSecurite = `${retirees} repas retire(s) par securite.`;
  return plan;
}

// --- API ---

// Besoins caloriques seuls (testable sans generation de plan).
app.post('/api/needs', (req, res) => {
  try {
    const besoins = calculerBesoins(req.body || {});
    res.json({ ok: true, besoins });
  } catch (e) {
    res.status(400).json({ ok: false, error: 'Profil invalide.' });
  }
});

// Genere un plan complet de la semaine.
app.post('/api/plan', async (req, res) => {
  const { profil = {}, preferences = {} } = req.body || {};
  const seed = seedFromRequest(req.body);
  try {
    let plan;
    let source = 'demo';
    if (iaDisponible()) {
      try {
        plan = await genererPlanIA(profil, preferences, seed);
        source = 'ia';
      } catch (e) {
        console.warn('Generation IA echouee, repli sur le mode demo :', e.message);
        plan = genererPlanDemo(profil, preferences, seed);
        source = 'demo-repli';
      }
    } else {
      plan = genererPlanDemo(profil, preferences, seed);
    }
    plan = filtreSecuriteFinal(plan, preferences);
    res.json({ ok: true, source, seed, plan });
  } catch (e) {
    console.error('Erreur /api/plan :', e);
    res.status(500).json({ ok: false, error: 'Generation impossible.' });
  }
});

// Regenere UN repas precis.
app.post('/api/meal', async (req, res) => {
  const { profil = {}, preferences = {}, creneau, kcalCible, exclureId } = req.body || {};
  const seed = seedFromRequest(req.body);
  try {
    let recette;
    if (iaDisponible()) {
      try {
        recette = await regenererRepasIA(profil, preferences, creneau, kcalCible, exclureId, seed);
      } catch (e) {
        console.warn('Regeneration IA echouee, repli demo :', e.message);
        recette = regenererRepas(profil, preferences, creneau, kcalCible, exclureId, seed);
      }
    } else {
      recette = regenererRepas(profil, preferences, creneau, kcalCible, exclureId, seed);
    }
    res.json({ ok: true, recette });
  } catch (e) {
    console.error('Erreur /api/meal :', e);
    res.status(500).json({ ok: false, error: 'Remplacement impossible.' });
  }
});

// Indique au front si l'IA est active (pour un petit badge).
app.get('/api/status', (req, res) => {
  res.json({ ok: true, ia: iaDisponible(), demo: !iaDisponible() });
});

app.listen(PORT, () => {
  const mode = iaDisponible() ? 'IA (Claude)' : 'DEMO (recettes locales)';
  console.log(`\n  My Coach Nutrition`);
  console.log(`  -> http://localhost:${PORT}`);
  console.log(`  Mode de generation : ${mode}\n`);
});
